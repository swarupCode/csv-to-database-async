package com.swarudas.csvtodatabase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CsvToDatabaseAsyncApplication {

	public static void main(String[] args) {
		SpringApplication.run(CsvToDatabaseAsyncApplication.class, args);
	}

}
